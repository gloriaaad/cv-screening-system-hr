package org.example;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PozicioniPunesTest {

    @Test
    void testPozicioniAktivNeFillim() {
        PozicioniPunes p = new PozicioniPunes();
        assertTrue(p.eshteAktiv());
    }

    @Test
    void testMbyllPozicionin() {
        PozicioniPunes p = new PozicioniPunes();
        p.mbyllPozicionin();
        assertFalse(p.eshteAktiv());
    }
}
