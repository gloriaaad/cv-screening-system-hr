package org.example;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class KandidatiTest {

    private Kandidati kandidati; // ndryshimi kryesor

    @BeforeEach
    void setUp() {
        kandidati = new Kandidati("Ana", "ana@gmail.com"); // ndryshimi kryesor
    }

    @Test
    void testLlogaritPike() {
        kandidati.llogaritPike(80);
        assertEquals(80, kandidati.getPike());
    }

    @Test
    void testNdryshoStatus() {
        kandidati.ndryshoStatus("Interviste");
        assertEquals("Interviste", kandidati.getStatusi());
    }
}
