package org.example;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class NjoftimiTest {

    @Test
    void testDergoNjoftim() {
        Njoftimi n = new Njoftimi();
        assertFalse(n.eshteDerguar());
        n.dergoNjoftim();
        assertTrue(n.eshteDerguar());
    }
}
