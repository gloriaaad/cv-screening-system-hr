package org.example;
public class Njoftimi {

    private boolean derguar;

    public Njoftimi() {
        this.derguar = false;
    }

    public void dergoNjoftim() {
        derguar = true;
    }

    public boolean eshteDerguar() {
        return derguar;
    }
}
