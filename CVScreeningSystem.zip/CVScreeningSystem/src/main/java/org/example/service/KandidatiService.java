package org.example.service;

import org.example.Kandidati;
import java.util.ArrayList;
import java.util.List;

public class KandidatiService {
    private List<Kandidati> kandidatet = new ArrayList<>();

    public void shtoKandidatin(Kandidati k) {
        kandidatet.add(k);
    }

    public void llogaritPiket(Kandidati k, double pikeReja) {
        k.llogaritPike(pikeReja);
    }

    public void ndryshoStatus(Kandidati k, String statusiRi) {
        k.ndryshoStatus(statusiRi);
    }

    public List<Kandidati> gjejKandidatet() {
        return kandidatet;
    }
}
