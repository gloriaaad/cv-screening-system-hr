package org.example.service;

import org.example.Njoftimi;
import java.util.ArrayList;
import java.util.List;

public class NjoftimiService {
    private List<Njoftimi> njoftimet = new ArrayList<>();

    public void shtoNjoftim(Njoftimi n) {
        njoftimet.add(n);
    }

    public void dergoNjoftim(Njoftimi n) {
        n.dergoNjoftim();
    }

    public List<Njoftimi> gjejTeDerguarit() {
        List<Njoftimi> derguar = new ArrayList<>();
        for (Njoftimi n : njoftimet) {
            if (n.eshteDerguar()) derguar.add(n);
        }
        return derguar;
    }
}
