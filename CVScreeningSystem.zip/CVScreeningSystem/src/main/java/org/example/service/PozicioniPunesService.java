package org.example.service;

import org.example.PozicioniPunes;
import java.util.ArrayList;
import java.util.List;

public class PozicioniPunesService {
    private List<PozicioniPunes> pozicionet = new ArrayList<>();

    public void shtoPozicion(PozicioniPunes p) {
        pozicionet.add(p);
    }

    public void publikojPozicion(PozicioniPunes p) {
        p.publikoPozicionin();
    }

    public void mbyllPozicion(PozicioniPunes p) {
        p.mbyllPozicionin();
    }

    public List<PozicioniPunes> gjejPozicionetAktive() {
        List<PozicioniPunes> aktive = new ArrayList<>();
        for (PozicioniPunes p : pozicionet) {
            if (p.eshteAktiv()) aktive.add(p);
        }
        return aktive;
    }
}
