package org.example.dto;

public class KandidatiDTO {
    private String emri;
    private String email;
    private double pike;
    private String statusi;

    // Konstruktor
    public KandidatiDTO() {}

    public KandidatiDTO(String emri, String email, double pike, String statusi) {
        this.emri = emri;
        this.email = email;
        this.pike = pike;
        this.statusi = statusi;
    }

    // Getters dhe Setters
    public String getEmri() { return emri; }
    public void setEmri(String emri) { this.emri = emri; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public double getPike() { return pike; }
    public void setPike(double pike) { this.pike = pike; }

    public String getStatusi() { return statusi; }
    public void setStatusi(String statusi) { this.statusi = statusi; }
}
