package org.example.dto;

public class NjoftimiDTO {
    private String mesazhi;
    private String lloji;
    private boolean derguar;

    public NjoftimiDTO() {}

    public NjoftimiDTO(String mesazhi, String lloji, boolean derguar) {
        this.mesazhi = mesazhi;
        this.lloji = lloji;
        this.derguar = derguar;
    }

    public String getMesazhi() { return mesazhi; }
    public void setMesazhi(String mesazhi) { this.mesazhi = mesazhi; }

    public String getLloji() { return lloji; }
    public void setLloji(String lloji) { this.lloji = lloji; }

    public boolean isDerguar() { return derguar; }
    public void setDerguar(boolean derguar) { this.derguar = derguar; }
}
