package org.example.dto;

public class PozicioniPunesDTO {
    private String titulli;
    private String departamenti;
    private boolean aktiv;

    public PozicioniPunesDTO() {}

    public PozicioniPunesDTO(String titulli, String departamenti, boolean aktiv) {
        this.titulli = titulli;
        this.departamenti = departamenti;
        this.aktiv = aktiv;
    }

    public String getTitulli() { return titulli; }
    public void setTitulli(String titulli) { this.titulli = titulli; }

    public String getDepartamenti() { return departamenti; }
    public void setDepartamenti(String departamenti) { this.departamenti = departamenti; }

    public boolean isAktiv() { return aktiv; }
    public void setAktiv(boolean aktiv) { this.aktiv = aktiv; }
}
