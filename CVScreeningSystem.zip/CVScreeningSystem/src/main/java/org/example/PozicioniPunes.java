package org.example;
public class PozicioniPunes {

    private boolean aktiv;

    public PozicioniPunes() {
        this.aktiv = true;
    }

    public void publikoPozicionin() {
        aktiv = true;
    }

    public void mbyllPozicionin() {
        aktiv = false;
    }

    public boolean eshteAktiv() {
        return aktiv;
    }
}
